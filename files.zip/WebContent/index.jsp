<%
  String username = (String) session.getAttribute("username");
  if(username == null) {
    response.sendRedirect("jsp/login.jsp");
  } else {
    response.sendRedirect("jsp/product_list.jsp");
  }
%>