<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>회원가입</title>
    <meta charset="UTF-8">
</head>
<body>
    <h2>회원가입</h2>
    <form action="register.jsp" method="post">
        아이디: <input type="text" name="username" required><br>
        비밀번호: <input type="password" name="password" required><br>
        이메일: <input type="email" name="email"><br>
        <input type="submit" value="회원가입">
        <a href="login.jsp">로그인 페이지로</a>
    </form>

    <%
        if(request.getMethod().equalsIgnoreCase("post")) {
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String email = request.getParameter("email");

            user.UserDAO dao = new user.UserDAO();
            boolean success = dao.register(username, password, email);

            if(success) {
                out.println("<p style='color:green;'>회원가입 성공! <a href='login.jsp'>로그인</a></p>");
            } else {
                out.println("<p style='color:red;'>회원가입 실패. 다시 시도하세요.</p>");
            }
        }
    %>
</body>
</html>