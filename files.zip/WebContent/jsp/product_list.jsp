<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="product.ProductDAO, product.Product, java.util.ArrayList" %>
<!DOCTYPE html>
<html>
<head>
    <title>상품 목록</title>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #4CAF50; color: white; }
    </style>
</head>
<body>
    <%
        String username = (String) session.getAttribute("username");
        if(username == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        ProductDAO dao = new ProductDAO();
        ArrayList<Product> products = dao.getAllProducts();
    %>

    <h2>상품 목록</h2>
    <p>안녕하세요, <strong><%= username %></strong>님!</p>
    <a href="cart.jsp">장바구니 보기</a> | <a href="../index.jsp">로그아웃</a>

    <table>
        <tr>
            <th>상품명</th>
            <th>가격</th>
            <th>설명</th>
            <th>수량</th>
            <th>동작</th>
        </tr>
        <%
            for(Product p : products) {
        %>
        <tr>
            <td><%= p.getName() %></td>
            <td><%= p.getPrice() %>원</td>
            <td><%= p.getDescription() %></td>
            <td>
                <form action="cart.jsp" method="post" style="display:inline;">
                    <input type="hidden" name="product_id" value="<%= p.getId() %>">
                    <input type="number" name="quantity" value="1" min="1" max="10" style="width:40px;">
                    <input type="submit" value="담기">
                </form>
            </td>
        </tr>
        <%
            }
        %>
    </table>
</body>
</html>