<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>로그인</title>
    <meta charset="UTF-8">
</head>
<body>
    <h2>로그인</h2>
    <form action="login.jsp" method="post">
        아이디: <input type="text" name="username" required><br>
        비밀번호: <input type="password" name="password" required><br>
        <input type="submit" value="로그인">
        <a href="register.jsp">회원가입</a>
    </form>

    <%
        if(request.getMethod().equalsIgnoreCase("post")) {
            String username = request.getParameter("username");
            String password = request.getParameter("password");

            user.UserDAO dao = new user.UserDAO();
            boolean success = dao.login(username, password);

            if(success) {
                session.setAttribute("username", username);
                response.sendRedirect("product_list.jsp");
            } else {
                out.println("<p style='color:red;'>로그인 실패. 아이디와 비밀번호를 확인하세요.</p>");
            }
        }
    %>
</body>
</html>