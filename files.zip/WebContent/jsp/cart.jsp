<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="cart.CartDAO, java.util.List, cart.CartItem" %>
<!DOCTYPE html>
<html>
<head>
    <title>장바구니</title>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #4CAF50; color: white; }
        .total { font-weight: bold; background-color: #f0f0f0; }
    </style>
</head>
<body>
    <%
        String username = (String) session.getAttribute("username");
        if(username == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        cart.CartDAO cartDao = new cart.CartDAO();

        // POST 요청으로 상품 장바구니에 추가
        if(request.getMethod().equalsIgnoreCase("POST")) {
            try {
                int productId = Integer.parseInt(request.getParameter("product_id"));
                int quantity = Integer.parseInt(request.getParameter("quantity"));
                cartDao.addToCart(username, productId, quantity);
            } catch (NumberFormatException e) {
                out.println("<p style='color:red;'>요청 처리 중 오류가 발생했습니다.</p>");
            }
        }

        List<CartItem> cartItems = cartDao.getCartItems(username);
    %>

    <h2>장바구니</h2>
    <p><strong><%= username %></strong>님의 장바구니</p>
    <a href="product_list.jsp">상품 목록</a>

    <% if(cartItems.isEmpty()) { %>
        <p>장바구니가 비어있습니다.</p>
    <% } else { %>
        <table>
            <tr>
                <th>상품명</th>
                <th>단가</th>
                <th>수량</th>
                <th>합계</th>
            </tr>
            <%
                int total = 0;
                for(CartItem item : cartItems) {
                    int price = item.getPrice() * item.getQuantity();
                    total += price;
            %>
            <tr>
                <td><%= item.getProductName() %></td>
                <td><%= item.getPrice() %>원</td>
                <td><%= item.getQuantity() %></td>
                <td><%= price %>원</td>
            </tr>
            <%
                }
            %>
            <tr class="total">
                <td colspan="2">총 합계</td>
                <td colspan="2"><%= total %>원</td>
            </tr>
        </table>
    <% } %>
</body>
</html>