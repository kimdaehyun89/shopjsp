# JSP 쇼핑몰 프로젝트 (Shopping Mall with JSP & MySQL)

이 프로젝트는 Java Server Pages(JSP)와 MySQL을 연동한 기본적인 쇼핑몰 전체 소스 예제입니다.

## 🎯 주요 기능
- 회원가입, 로그인 (세션)
- 상품 목록 조회
- 장바구니 기능

## 설치 및 실행
1. MySQL에서 `sql/shopdb_setup.sql` 실행
2. `src/util/DBUtil.java`에서 DB 연결 정보 수정 (USER, PASSWORD)
3. MySQL Connector/J 를 `WebContent/WEB-INF/lib`에 배치
4. Tomcat에 프로젝트 배포 (WAR 또는 IDE에서 바로 실행)
5. 브라우저 접속: `http://localhost:8080/shopjsp`

## 보안 안내
- 학습용 예제입니다. 실제 서비스에서는 비밀번호 암호화, 입력 검증, HTTPS, CSRF 토큰 등을 적용하세요.