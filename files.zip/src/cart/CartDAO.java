package cart;

import util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDAO {
    public void addToCart(String username, int productId, int quantity) {
        try (Connection conn = DBUtil.getConnection()) {
            // 사용자 id 조회
            String userSql = "SELECT id FROM users WHERE username = ?";
            PreparedStatement psUser = conn.prepareStatement(userSql);
            psUser.setString(1, username);
            ResultSet rsUser = psUser.executeQuery();
            if(!rsUser.next()) return;
            int userId = rsUser.getInt("id");

            // 장바구니에 이미 상품이 있으면 수량 업데이트, 없으면 삽입
            String checkSql = "SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?";
            PreparedStatement psCheck = conn.prepareStatement(checkSql);
            psCheck.setInt(1, userId);
            psCheck.setInt(2, productId);
            ResultSet rsCheck = psCheck.executeQuery();

            if(rsCheck.next()) {
                int cartId = rsCheck.getInt("id");
                int oldQty = rsCheck.getInt("quantity");
                String updateSql = "UPDATE cart SET quantity = ? WHERE id = ?";
                PreparedStatement psUpdate = conn.prepareStatement(updateSql);
                psUpdate.setInt(1, oldQty + quantity);
                psUpdate.setInt(2, cartId);
                psUpdate.executeUpdate();
            } else {
                String insertSql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)";
                PreparedStatement psInsert = conn.prepareStatement(insertSql);
                psInsert.setInt(1, userId);
                psInsert.setInt(2, productId);
                psInsert.setInt(3, quantity);
                psInsert.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<CartItem> getCartItems(String username) {
        List<CartItem> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT p.name, p.price, c.quantity FROM cart c JOIN users u ON c.user_id = u.id JOIN products p ON c.product_id = p.id WHERE u.username = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                CartItem item = new CartItem();
                item.setProductName(rs.getString("name"));
                item.setPrice(rs.getInt("price"));
                item.setQuantity(rs.getInt("quantity"));
                list.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}