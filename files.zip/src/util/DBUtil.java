package util;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * 데이터베이스 연결 유틸리티 클래스
 */
public class DBUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/shopdb?useUnicode=true&characterEncoding=utf8&serverTimezone=UTC";
    private static final String USER = "root";  // MySQL 사용자명
    private static final String PASSWORD = "your_password";  // MySQL 비밀번호

    /**
     * 데이터베이스 연결 객체 반환
     * @return Connection 데이터베이스 연결 객체
     * @throws Exception 연결 실패 시 예외 발생
     */
    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}